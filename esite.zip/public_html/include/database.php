<?php

$dbServername = "localhost";
$dbUsername = "id14983187_esitedb";
$dbPassword = "&7gH{7e?E/dE>s|W";
$dbName = "id14983187_esite";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);

if (!$conn) {
	die("connection failed: ".mysqli_connect_error());
}