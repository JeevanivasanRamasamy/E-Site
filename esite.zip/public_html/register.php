<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="index.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="stylesheet" href="font-awesome.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Comic+Neue:wght@700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
</head>
<style type="text/css">
    body
    {
    font-family: 'Comic Neue';
    background:linear-gradient(to bottom, #33ccff 0%, #ff99cc 100%);
    width:100%;
    background-repeat:no-repeat;
  

    }

h1 {
  font-family: "Work Sans", sans-serif;
  font-weight: 800;
  font-size: 5em;
  width: 5em;
  line-height: 0.9em;
  margin-left: auto;
  margin-right: auto;
  margin-top: 1.5em;
  margin-top: calc(50vh - 1em);
}

.rainbow-text {
  background: #CA4246;
  background-color: #CA4246;
  background: conic-gradient(
    #CA4246 16.666%, 
    #E16541 16.666%, 
    #E16541 33.333%, 
    #F18F43 33.333%, 
    #F18F43 50%, 
    #8B9862 50%, 
    #8B9862 66.666%, 
    #476098 66.666%, 
    #476098 83.333%, 
    #A7489B 83.333%);
  
  background-size: 57%;
  background-repeat: repeat;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent; 
  
  animation: rainbow-text-animation-rev 0.5s ease forwards;

  cursor: pointer;
}

.rainbow-text:hover {
  animation: rainbow-text-animation 0.5s ease forwards;
}
@keyframes rainbow-text-animation {
  0% {
    background-size: 57%;
    background-position: 0 0;
  }
  20% {
    background-size: 57%;
    background-position: 0 1em;
  }
  100% {
    background-size: 300%;
    background-position: -9em 1em;
  }
}

@keyframes rainbow-text-animation-rev {
  0% {
    background-size: 300%;
    background-position: -9em 1em;
  }
  20% {
    background-size: 57%;
    background-position: 0 1em;
  }
  100% {
    background-size: 57%;
    background-position: 0 0;
  }
}
.signupessage
{
  text-align: center;
  color: black;
  font-size: 13px;
  background-color:#ffff66;
  margin-top:20px;
  border-radius:3px;
}
</style>
<body>
    <div class="container">
    <!--top nav-->
    <nav class="navbar navbar-fixed-top" style="background-color:#d9d9d9;height: 65px ">
        <div class="container-fluid">
        <a href="#" class="text-center navbar-brand" style="color: black;font-family: 'Comic Neue'; padding-left: 15px;"><b style="font-size: 25px;">
        <b style="padding-left: 18px;" class="rainbow-text">E-SITE</b></a>
        </div>
    </nav>
<!--body-->
    <div class="row" style="padding-top: 100px;">
        <div class="col-xs-offset-1 col-xs-10">
            <h3 class="text-center"><b>Register your account</b></h3>
            <div>
                <form action="include/register.inc.php" method="post">
                    <div class="page">
  <?php
    if (isset($_GET['register'])) {
      if ($_GET['register'] == "empty") {
        echo '<p class="signupessage">All fields required</p>';
      }
      else if ($_GET['register'] == "invalid") {
        echo '<p class="signupessage">Only A-Z & a-z allowed in name</p>';  
      }
       else if ($_GET['register'] == "pwd") {
        echo '<p class="signupessage">Password & Confirm Password not match</p>';  
      }
      else if ($_GET['register'] == "email") {
        echo '<p class="signupessage">Invalid E-mail</p>';  
      }
      else if ($_GET['register'] == "emailtaken") {
        echo '<p class="signupessage">Email already exist</p>';  
      }
      elseif ($_GET['register'] == "success") {
        echo '<p class="signupessage">Signup success, make login</p>';  
    }
    }
  
    ?>
                    <div class="text-right" style="margin-top:10px;color:white;">
                        <a class=" btn btn-lg" href="login.php" style="color:white;">Login?</a>
                    </div>
                    <div class="text-center">
                        <a data-toggle="modal" data-target="#modal" style="font-size:19px;">Why Register?</a>
                            <div class="modal fade" id="modal"role="dialog">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-body">
                                            <p>Why Login?</p><p style="font-size:18px;text-align:justify;">E-Site requires a registration in order to do the login process whenever you tries to acces the site. It is purely used to maintain the user details, their feedback etc.</p>
                                        </div>
                                        <div class="modal-footer">
                                            <a class="btn btn-default" data-dismiss="modal">Close</a>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                    <div class="form-group" style="margin-top:15px;">
                        <input type="text" class="form-control" id="name" name="name" placeholder="Enter Name" required="">
                    </div>
                    <div class="form-group">
                     <input type="email" class="form-control" id="email" name="email" placeholder="Enter E-Mail" required="">
                    </div>
                    <div class="form-group">
                    <input type="Password" class="form-control" id="pwd" name="pwd" placeholder="Enter Password" required="">
                    </div>
                    <div class="form-group">
                    <input type="Password" class="form-control" id="cpwd" name="cpwd" placeholder="Confirm Password" required="">
                    </div>
                    <div style="padding-top:10px;" class="text-center">
                        <button name="submit" type="submit" class="btn btn-md">Submit</button>
                    </div>
                    <div>
                        <p class="text-center" style="color:white;margin-top:15px;font-size:18px;">OR</p><hr><br>
                        <div class="text-center">
                            <a href="login.php"><h4>Already have an account ? <b class="rainbow-text">Login</b></h4></a>
                        </div>
                    </div>
            </div>
          </form>
        </div>
      </div>
    </div>

        <br>
          <!--body-->

 

    <div class="container"><hr></div>
    <p class="text-center" style="font-size:14px;"><i class="fa fa-copyright" aria-hidden="true"></i> 2020 Exclusive. | Design by JEEVA</p><br><br>
    
</div>
</body>
</html>