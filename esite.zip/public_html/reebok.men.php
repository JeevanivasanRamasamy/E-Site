<?php 

session_start();
if (!isset($_SESSION['check'])) {
  
  header('location:login.php?msg=<p class="signupessage">Make signin to access E-Site</p>');
}
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>REEBOK</title>
	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  	<link rel="stylesheet" type="text/css" href="index.css">
  	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  	<script src="https://kit.fontawesome.com/a076d05399.js"></script>
  	<link rel="stylesheet" href="font-awesome.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<link rel="stylesheet" type="text/css" href="dist/sweetalert.css">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Comic+Neue:wght@700&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
</head>
<style type="text/css">
	body
	{
		font-family: 'Comic Neue'
	}
	
.sidepanel  {
  width: 0;
  position: fixed;
  z-index: 1;
  height: 100%;
  top: 0;
  left: 0;
  background-color: #d9d9d9;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidepanel a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 15px;
  color: black;
  display: block;
  transition: 0.3s;
}


.sidepanel .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
}

.affix
{
  top: 0;
  width: 100%;
  z-index: 9999! important;
}
.affix + .container-fluid
{
  padding-top: 70px;
}
/* General styling of the page. */
/* Sets a background color, font-size etc. */


h1 {
  font-family: "Work Sans", sans-serif;
  font-weight: 800;
  font-size: 5em;
  width: 5em;
  line-height: 0.9em;
  margin-left: auto;
  margin-right: auto;
  margin-top: 1.5em;
  margin-top: calc(50vh - 1em);
}


/* Style the rainbow text element. */
.rainbow-text {
  /* Create a conic gradient. */
  /* Double percentages to avoid blur (#000 10%, #fff 10%, #fff 20%, ...). */
  background: #CA4246;
  background-color: #CA4246;
  background: conic-gradient(
    #CA4246 16.666%, 
    #E16541 16.666%, 
    #E16541 33.333%, 
    #F18F43 33.333%, 
    #F18F43 50%, 
    #8B9862 50%, 
    #8B9862 66.666%, 
    #476098 66.666%, 
    #476098 83.333%, 
    #A7489B 83.333%);
  
  /* Set thee background size and repeat properties. */
  background-size: 57%;
  background-repeat: repeat;
  
  /* Use the text as a mask for the background. */
  /* This will show the gradient as a text color rather than element bg. */
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent; 
  
  /* Animate the text when loading the element. */
  /* This animates it on page load and when hovering out. */
  animation: rainbow-text-animation-rev 0.5s ease forwards;

  cursor: pointer;
}

/* Add animation on hover. */
.rainbow-text:hover {
  animation: rainbow-text-animation 0.5s ease forwards;
}

/* Move the background and make it larger. */
/* Animation shown when hovering over the text. */
@keyframes rainbow-text-animation {
  0% {
    background-size: 57%;
    background-position: 0 0;
  }
  20% {
    background-size: 57%;
    background-position: 0 1em;
  }
  100% {
    background-size: 300%;
    background-position: -9em 1em;
  }
}

/* Move the background and make it smaller. */
/* Animation shown when entering the page and after the hover animation. */
@keyframes rainbow-text-animation-rev {
  0% {
    background-size: 300%;
    background-position: -9em 1em;
  }
  20% {
    background-size: 57%;
    background-position: 0 1em;
  }
  100% {
    background-size: 57%;
    background-position: 0 0;
  }
}
</style>
<body>
		<nav class="navbar navbar-inverse navbar-fixed-bottom">
		<div class="container-fluid">
			<div>
				<ul class="nav" style="letter-spacing:2px;font-family: 'Comic Neue', cursive;">
					<div class="row text-center" style="font-size: 20px;padding-top: 8px;">
						<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
            <a href="index.php" style="color: white;"><i class="fa fa-home" aria-hidden="true"></i></a>
            </div>  
            <div class="col-xs-4  col-sm-4 col-md-4 col-lg-4">
            <a href="myaccount.php" style="color: white;"><i class="fa fa-user" aria-hidden="true"></i></a>
            </div>
            <div class="col-xs-4  col-sm-4 col-md-4 col-lg-4">
            <a href="help.php" style="color: white"><i class="fa fa-info-circle" aria-hidden="true"></i></a>
            </div>		
					</div>
				</ul>
			</div>
		</div>
	</nav>
	<!--top nav-->
	<nav class="navbar" style="background-color:#d9d9d9;height: 65px ">
		<div class="container-fluid">

				<a href="#" class="text-center navbar-brand" style="color: black;font-family: 'Comic Neue'; padding-left: 15px;"><b style="font-size: 25px;">

				<button onclick="openNav()"><i class="fa fa-bars" aria-hidden="true"></i></button> <b style="padding-left: 18px;" class="rainbow-text">E-SITE</b></a>
				

			<div style="font-family: 'Comic Neue';">
				<div id="mySidepanel" class="sidepanel text-left">
     				 <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
     				 <a style="font-size: 30px;" href="index.php" class="rainbow-text">E-site</a>
     				 <div class="dropdown">
     				 <a style="font-size: 20px;" href="#" class="dropdown-toggle" data-toggle="dropdown">My Projects <span class="caret"></span></a>
     					<ul class="dropdown-menu dropdown-menu-right">
     				 		<li><a href="http://jeeva-portfolio.000webhostapp.com">Personal Portfolio</a></li>
     				 		<li><a href="http://ad-site.000webhostapp.com">Ad-site</a></li>
     				 		<li><a href="http://learnbasics-course.000webhostapp.com">Learnbasics</a></li>
     				 	</ul>
     				 </div>
     				<div class="dropdown">
            		 <a style="font-size: 20px;" href="#" class="dropdown-toggle" data-toggle="dropdown">Contact Us<span class="caret"></span></a>
              <ul class="dropdown-menu dropdown-menu-right text-center" style="font-size: 25px;">
                  <li><a href="https://www.facebook.com/jeevanivasan.ramasamy">Facebook</a></li>
                  <li><a href="https://www.linkedin.com/in/jeeva-nivasan-ramasamy-357405181">Linkedin</a></li>
                  <li><a href="https://github.com/JeevanivasanRamasamy">Github</a></li>
                  <li><a href="https://instagram.com/the.nivas?igshid=1eg1vfvnmhz83">Instagram</a></li>
                  <li><a href="https://mobile.twitter.com/Jeeva_Nivasan">Twitter</a></li>
              </ul>
             </div>
     				 <a style="font-size: 20px;" href="about.php">About Us</a>
     				 <a style="font-size: 20px;" href="help.php">Help</a><br>
     				<div>
     				 	<a href="Register.php"><button type="button" class="btn btn-lg" style="width: 90%;background-color: #4ad294;color: white">Register</button></a>

     				 	<a href="login.php"><button class="btn btn-lg" style="width: 90%;border-style:double;text-align: center;border-style: solid;border-width: 3px;border-color: #cccccc;margin-top: 3px">Login</button></a>
     				 </div>
  				</div>
			</div>
		</div>
	</nav>

		<div class="row">
			<p class="text-center rainbow-text">E-SITE / REEBOK / MEN</p><br>
			<div class="col-xs-offset-1 col-xs-4 well text-center">
				<a href="#" class="btn btn-lg">SHIRT</a>
			</div>
			<div class="col-xs-offset-2 col-xs-4 well text-center">
				<a href="#" class="btn btn-lg">T-SHIRT</a>
			</div>
			<div class="col-xs-offset-1 col-xs-4 well text-center">
				<a href="#" class="btn btn-lg">JEANS</a>
			</div>
			<div class="col-xs-offset-2 col-xs-4 well text-center">
				<a href="#" class="btn btn-lg">TROUSERS</a>
			</div>
      <div class="col-xs-offset-1 col-xs-4 well text-center">
        <a href="#" class="btn btn-lg">SUNGLASSES</a>
      </div>
      <div class="col-xs-offset-2 col-xs-4 well text-center">
        <a href="#" class="btn btn-lg">FLIP FLOPS</a>
      </div>

			
		</div>
		<div class="text-center">

		<a href="reebok.php" class="btn btn-default text-center"><i class="fa fa-angle-left" aria-hidden="true"></i> Back</a>
			
		</div>
    <hr>
    <p class="text-center"><i class="fa fa-copyright" aria-hidden="true"></i> 2020 Exclusive. | Design by JEEVA</p>
<script>
function openNav() {
  document.getElementById("mySidepanel").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidepanel").style.width = "0";
}
</script>

</body>
</html>